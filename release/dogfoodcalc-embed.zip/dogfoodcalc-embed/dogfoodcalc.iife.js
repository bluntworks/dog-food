var DogFoodCalc=(function(e){Object.defineProperty(e,Symbol.toStringTag,{value:`Module`});var t=[{name:`group 1`,adjustment:.1,breeds:[`mixed breed`,`golden retriever`,`cockapoo`,`german shepherd`,`poodle`,`cocker spaniel`,`cavapoo`,`irish terrier`,`spitz`,`kerry blue terrier`,`soft coated`,`wheaten terrier`,`irish water spaniel`,`kerry beagle`,`mixed breed`,`beagle`,`chihuahua`,`yorkshire`,`rottweiler`,`akita`,`pinscher`,`cane corso`,`shiba`]},{name:`group 2`,adjustment:0,breeds:`bichon frise.dachshund.irish wolfhound.maltese.saint bernard.shar pei.great dane.glen of imaal terrier.english springer spaniel.border terrier.labradoodle.poodle.pomeranian.schnauzer.doberman.boxer.newfoundland.great pyrenees.chow chow.samoyed.gordon setter.bearded collie.cavalier king charles spaniel.cairn terrier.west highland white terrier.scottish terrier.labrador`.split(`.`)},{name:`group 3`,adjustment:-.1,breeds:[`french bulldog`,`english bulldog`,`basset`,`corgi`,`staffordshire bull terrier`]},{name:`group 4`,adjustment:-.2,breeds:[`pug`]},{name:`group 5`,adjustment:-.05,breeds:[`shih tzu`,`american bulldog`,`lhasa apso`]},{name:`group 6`,adjustment:.2,breeds:[`jack russell`,`irish setter (red or white)`,`border collie`,`malinois`,`siberian husky`,`greyhound`,`whippet`,`boxer`,`australian shepherd`,`weimaraner`,`saluki`,`pointer`,`vizsla`,`kelpie`]},{name:`group 7`,adjustment:.15,breeds:[`doberman`,`dalmatian`]}],n=.1,r=e=>e<1?null:e<=2?{delta:.1,description:`Age adjustment (${e}y): +0.1`}:e<=5?{delta:0,description:`Age adjustment (${e}y): 0`}:e<=8?{delta:-.1,description:`Age adjustment (${e}y): -0.1`}:{delta:-.1,description:`Age adjustment (>8y): -0.1`},i={low:-.2,moderate:0,high:.3},a=e=>{let t=i[e];return{delta:t,description:t===0?`No activity adjustment ('${e}')`:`Activity adjustment ('${e}'): ${d(t)}`}},o={"ideal weight":0,overweight:-.2,underweight:.2},s=e=>{let t=o[e];return{delta:t,description:t===0?`No body-condition adjustment ('${e}')`:`Body-condition adjustment ('${e}'): ${d(t)}`}},c={"spayed female":-.2,"neutered male":-.1,"intact female":0,"intact male":.1},l=e=>{let t=c[e];return{delta:t,description:t===0?`No spay/neuter adjustment ('${e}')`:`Spay/neuter adjustment ('${e}'): ${d(t)}`}},u=e=>{let r=e.trim().toLowerCase();for(let e of t)if(e.breeds.includes(r))return{delta:e.adjustment,description:`Breed adjustment (${e.name}): ${d(e.adjustment)}`};return{delta:n,description:`Breed adjustment (other): ${d(n)}`}},d=e=>e>=0?`+${e}`:`${e}`,f=1.4,p=e=>{let t=r(e.ageYears);if(t===null)return{status:`rejected`,reason:`puppy-under-one`,message:`Diet is not recommended for puppies under 1 year old.`};let n=[`Initial FCB: ${f.toFixed(2)}`],i=f+t.delta;n.push(`${t.description} → FCB = ${i.toFixed(2)}`);let o=a(e.activity);i+=o.delta,n.push(`${o.description} → FCB = ${i.toFixed(2)}`);let c=s(e.bodyCondition);i+=c.delta,n.push(`${c.description} → FCB = ${i.toFixed(2)}`);let d=l(e.spayNeuter);i+=d.delta,n.push(`${d.description} → FCB = ${i.toFixed(2)}`);let p=u(e.breed),m=i+p.delta;return n.push(`${p.description} → FCT = ${m.toFixed(2)}`),{status:`ok`,fct:m,nemKcal:Math.round(95*e.weightKg**.75*m),steps:n}},m=(e,t)=>Math.round(e/(t/1e3)),h=(e,t,n)=>{if(t===`food-only`)return{mode:`food-only`,foodKcal:e,foodGrams:m(e,n.foodKcalPerKg)};let r=Math.round(e*(n.foodSplitPercent/100)),i=e-r;return{mode:`mixed`,foodKcal:r,foodGrams:m(r,n.foodKcalPerKg),kibbleKcal:i}},g=`
  <svg class="dogfood-calc__hero-illustration" viewBox="0 0 120 120" fill="none" aria-hidden="true">
    <ellipse cx="60" cy="84" rx="46" ry="10" fill="currentColor" opacity="0.12"/>
    <path d="M18 70 Q60 100 102 70 L96 84 Q60 102 24 84 Z" fill="currentColor"/>
    <ellipse cx="60" cy="68" rx="42" ry="9" fill="currentColor" opacity="0.5"/>
    <circle cx="48" cy="64" r="4" fill="currentColor"/>
    <circle cx="62" cy="66" r="5" fill="currentColor"/>
    <circle cx="76" cy="63" r="3.5" fill="currentColor"/>
    <circle cx="55" cy="60" r="3" fill="currentColor"/>
    <circle cx="70" cy="60" r="2.5" fill="currentColor"/>
    <path d="M40 32 q4 -10 10 0 M58 26 q4 -10 10 0 M76 32 q4 -10 10 0 M30 44 q4 -10 10 0" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" fill="none" opacity="0.6"/>
  </svg>
`,_=(e,t)=>`
    <div class="dogfood-calc__header">
      <h2>${y(t.heading)}</h2>
      <p>${y(t.subheading)}</p>
    </div>

    <div class="dogfood-calc__layout">
      <form class="dogfood-calc__form" id="${e}-form" novalidate>
        <div class="dogfood-calc__grid">
          <div class="dogfood-calc__field dogfood-calc__field--full">
            <label for="${e}-breed">Your dog's breed</label>
            <input id="${e}-breed" data-field="breed" type="text" list="${e}-breed-list" placeholder="e.g. cockapoo" autocomplete="off" />
            <datalist id="${e}-breed-list"></datalist>
          </div>

          <div class="dogfood-calc__field">
            <label for="${e}-age">Your dog's age</label>
            <select id="${e}-age" data-field="age">
              <option value="puppy">Under 1 year</option>
              <option value="1-2" selected>1–2 years</option>
              <option value="3-5">3–5 years</option>
              <option value="6-8">6–8 years</option>
              <option value="9+">9+ years</option>
            </select>
          </div>

          <div class="dogfood-calc__field">
            <label for="${e}-weight">Your dog's weight (kg)</label>
            <input id="${e}-weight" data-field="weight" type="number" min="0.5" step="0.1" placeholder="e.g. 12" required />
          </div>
        </div>

        <div class="dogfood-calc__more" data-more>
          <button type="button" class="dogfood-calc__more-toggle" data-more-toggle>
            More about your dog
          </button>
          <div class="dogfood-calc__more-panel">
            <div class="dogfood-calc__grid">
              <div class="dogfood-calc__field">
                <label for="${e}-activity">Activity level</label>
                <select id="${e}-activity" data-field="activity">
                  <option value="low">Low</option>
                  <option value="moderate" selected>Moderate</option>
                  <option value="high">High</option>
                </select>
              </div>
              <div class="dogfood-calc__field">
                <label for="${e}-body">Body condition</label>
                <select id="${e}-body" data-field="body">
                  <option value="ideal weight" selected>Ideal weight</option>
                  <option value="overweight">Overweight</option>
                  <option value="underweight">Underweight</option>
                </select>
              </div>
              <div class="dogfood-calc__field dogfood-calc__field--full">
                <label for="${e}-spay">Spay / neuter status</label>
                <select id="${e}-spay" data-field="spay">
                  <option value="spayed female">Spayed female</option>
                  <option value="neutered male">Neutered male</option>
                  <option value="intact female">Intact female</option>
                  <option value="intact male" selected>Intact male</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        <button type="submit" class="dogfood-calc__submit">${y(t.ctaLabel)}</button>
      </form>

      <aside
        class="dogfood-calc__panel${t.heroImageUrl?` dogfood-calc__panel--image`:``}"
        ${t.heroImageUrl?`style="background-image:url('${v(t.heroImageUrl)}');background-position:${v(t.heroImagePosition)};background-size:${t.heroImageFit};"`:``}
        ${t.heroImageUrl?`role="img" aria-label="${v(t.heroImageAlt)}"`:``}
        aria-live="polite"
      >
        <div class="dogfood-calc__hero" data-hero>
          ${t.heroImageUrl?``:`${g}
                 <p class="dogfood-calc__hero-title">A meal plan, made just for them</p>
                 <p class="dogfood-calc__hero-text">
                   Tell us a few things about your dog and we'll work out their daily energy needs and food portion.
                 </p>`}
        </div>

        <div class="dogfood-calc__result" data-result hidden>
          <p class="dogfood-calc__nem-label">Daily energy need</p>
          <p class="dogfood-calc__nem">
            <span data-output-nem>0</span><span class="dogfood-calc__nem-unit">kcal / day</span>
          </p>
          <div class="dogfood-calc__serving" data-output-serving></div>
          ${t.enableMixedMode?`<div class="dogfood-calc__mode" role="group" aria-label="Serving mode">
                   <button type="button" data-mode-btn="food-only" aria-pressed="${t.defaultMode===`food-only`}">Only food</button>
                   <button type="button" data-mode-btn="mixed" aria-pressed="${t.defaultMode===`mixed`}">Food + kibble</button>
                 </div>`:``}
          <button type="button" class="dogfood-calc__steps-toggle" data-steps-toggle>
            How we got this
          </button>
          <ol class="dogfood-calc__steps" data-output-steps hidden></ol>
        </div>
      </aside>
    </div>
  `,v=e=>y(e),y=e=>e.replace(/[&<>"']/g,e=>{switch(e){case`&`:return`&amp;`;case`<`:return`&lt;`;case`>`:return`&gt;`;case`"`:return`&quot;`;case`'`:return`&#39;`;default:return e}}),b={heading:`Build your dog's feeding plan`,subheading:`Tell us a bit about your dog and we'll work out their daily energy needs.`,ctaLabel:`Calculate daily portion`,foodKcalPerKg:1345,kibbleKcalPerKg:1345,foodSplitPercent:80,defaultMode:`mixed`,enableMixedMode:!0,heroImageUrl:``,heroImageAlt:`Happy dog ready for their meal`,heroImagePosition:`center`,heroImageFit:`cover`},x=0,S=e=>{let t=e.dataset;return{heading:t.heading??b.heading,subheading:t.subheading??b.subheading,ctaLabel:t.ctaLabel??b.ctaLabel,foodKcalPerKg:C(t.foodKcalPerKg,b.foodKcalPerKg),kibbleKcalPerKg:C(t.kibbleKcalPerKg,b.kibbleKcalPerKg),foodSplitPercent:C(t.foodSplitPercent,b.foodSplitPercent),defaultMode:t.defaultMode===`food-only`?`food-only`:`mixed`,enableMixedMode:t.enableMixedMode!==`false`,heroImageUrl:t.heroImageUrl??b.heroImageUrl,heroImageAlt:t.heroImageAlt??b.heroImageAlt,heroImagePosition:t.heroImagePosition??b.heroImagePosition,heroImageFit:t.heroImageFit===`contain`?`contain`:`cover`}},C=(e,t)=>{if(e===void 0)return t;let n=Number(e);return Number.isFinite(n)&&n>0?n:t},w=new WeakMap,T=e=>{if(e.dataset.dogfoodCalcMounted===`true`)return;e.dataset.dogfoodCalcMounted=`true`;let t=S(e),n=`dfc-${++x}`;e.classList.add(`dogfood-calc`),e.innerHTML=_(n,{heading:t.heading,subheading:t.subheading,ctaLabel:t.ctaLabel,defaultMode:t.defaultMode,enableMixedMode:t.enableMixedMode,heroImageUrl:t.heroImageUrl,heroImageAlt:t.heroImageAlt,heroImagePosition:t.heroImagePosition,heroImageFit:t.heroImageFit}),E(e,n),w.set(e,{config:t,lastResult:null,currentMode:t.defaultMode}),D(e),O(e),k(e),A(e)},E=(e,n)=>{let r=e.querySelector(`#${n}-breed-list`);if(!r)return;let i=new Set;for(let e of t)for(let t of e.breeds){if(i.has(t))continue;i.add(t);let e=document.createElement(`option`);e.value=t.replace(/\b\w/g,e=>e.toUpperCase()),r.appendChild(e)}},D=e=>{let t=e.querySelector(`form`);t&&t.addEventListener(`submit`,t=>{t.preventDefault(),j(e)})},O=e=>{let t=e.querySelector(`[data-more]`),n=e.querySelector(`[data-more-toggle]`);!t||!n||n.addEventListener(`click`,()=>{let e=t.dataset.open===`true`;t.dataset.open=e?`false`:`true`})},k=e=>{let t=e.querySelectorAll(`[data-mode-btn]`);t.forEach(n=>{n.addEventListener(`click`,()=>{let r=n.dataset.modeBtn,i=w.get(e);i&&(i.currentMode=r,t.forEach(e=>e.setAttribute(`aria-pressed`,e.dataset.modeBtn===r?`true`:`false`)),i.lastResult&&L(e,i))})})},A=e=>{let t=e.querySelector(`[data-steps-toggle]`),n=e.querySelector(`[data-output-steps]`);!t||!n||t.addEventListener(`click`,()=>{n.hidden=!n.hidden,t.textContent=n.hidden?`How we got this`:`Hide details`})},j=e=>{let t=w.get(e);if(!t)return;let n=N(e);if(!n){B(e,`Please enter a valid weight in kilograms.`);return}let r=p(n);if(r.status===`rejected`){B(e,r.message);return}t.lastResult=r,I(e,t)},M=e=>{switch(e){case`puppy`:return .5;case`1-2`:return 2;case`3-5`:return 4;case`6-8`:return 7;case`9+`:return 10;default:return 4}},N=e=>{let t=P(e,`weight`),n=F(e,`age`)??`3-5`,r=F(e,`breed`)??``,i=F(e,`activity`)??`moderate`,a=F(e,`body`)??`ideal weight`,o=F(e,`spay`)??`intact male`;return t===null||t<=0?null:{weightKg:t,ageYears:M(n),activity:i,bodyCondition:a,spayNeuter:o,breed:r}},P=(e,t)=>{let n=e.querySelector(`[data-field="${t}"]`);if(!n||n.value===``)return null;let r=Number(n.value);return Number.isFinite(r)?r:null},F=(e,t)=>e.querySelector(`[data-field="${t}"]`)?.value??null,I=(e,t)=>{let n=e.querySelector(`[data-hero]`),r=e.querySelector(`[data-result]`),i=e.querySelector(`[data-output-nem]`);!n||!r||!i||!t.lastResult||(n.hidden=!0,r.hidden=!1,i.classList.remove(`dogfood-calc__warn`),i.textContent=String(t.lastResult.nemKcal),L(e,t),z(e,t.lastResult.steps))},L=(e,t)=>{if(!t.lastResult)return;let n=e.querySelector(`[data-output-serving]`);if(!n)return;let r={foodKcalPerKg:t.config.foodKcalPerKg,kibbleKcalPerKg:t.config.kibbleKcalPerKg,foodSplitPercent:t.config.foodSplitPercent},i=t.config.enableMixedMode?t.currentMode:`food-only`;n.innerHTML=R(h(t.lastResult.nemKcal,i,r),t.config)},R=(e,t)=>{if(e.mode===`food-only`)return`<strong>${e.foodGrams} g</strong> of food per day
      <br><span style="color:var(--dfc-muted);font-size:0.85em">
      Based on ${t.foodKcalPerKg} kcal/kg.</span>`;let n=100-t.foodSplitPercent;return`<strong>${e.foodGrams} g</strong> of food
    <span style="color:var(--dfc-muted)">(${t.foodSplitPercent}%, ${e.foodKcal} kcal)</span>
    <br>+ <strong>${e.kibbleKcal} kcal</strong> of kibble
    <span style="color:var(--dfc-muted)">(${n}%)</span>`},z=(e,t)=>{let n=e.querySelector(`[data-output-steps]`),r=e.querySelector(`[data-steps-toggle]`);n&&(n.innerHTML=t.map(e=>`<li>${e}</li>`).join(``),n.hidden=!0,r&&(r.textContent=`How we got this`))},B=(e,t)=>{let n=e.querySelector(`[data-hero]`),r=e.querySelector(`[data-result]`),i=e.querySelector(`[data-output-nem]`),a=e.querySelector(`[data-output-serving]`),o=e.querySelector(`[data-output-steps]`);!n||!r||!i||!a||!o||(n.hidden=!0,r.hidden=!1,i.classList.add(`dogfood-calc__warn`),i.textContent=`—`,a.innerHTML=`<span class="dogfood-calc__warn">${t}</span>`,o.innerHTML=``,o.hidden=!0)},V=`[data-dogfood-calc]`,H=()=>{document.querySelectorAll(V).forEach(e=>T(e))};return document.readyState===`loading`?document.addEventListener(`DOMContentLoaded`,H,{once:!0}):H(),new MutationObserver(()=>H()).observe(document.documentElement,{childList:!0,subtree:!0}),window.DogFoodCalc={mountAll:H,mount:T},e.mountAll=H,e.mountWidget=T,e})({});